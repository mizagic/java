package jvavancado.beans;

public class Clientes {

    private int id;
    private int idade;
    private String nome;
    private String telefone;
    private String email;
    private String estadoCivil;
    private String profissão;
    private String sexo;
    private Double salario;

    /**
     * ESSE METODO É OCONSTRUTOR ELE EXECUTA CADA VEZ QUE DER NEW CLIENTE(),
     * SERVE POR EXEMPLO PARA DEFINIR UM VALOR DEFAULT DE INICIALIZAÇAO DE UM
     * CAMPO
     */
    public Clientes() {
        sexo = "masculino";
    }

    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the estadoCivil
     */
    public String getEstadoCivil() {
        return estadoCivil;
    }

    /**
     * @param estadoCivil the estadoCivil to set
     */
    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    /**
     * @return the profissão
     */
    public String getProfissão() {
        return profissão;
    }

    /**
     * @param profissão the profissão to set
     */
    public void setProfissão(String profissão) {
        this.profissão = profissão;
    }

    /**
     * @return the sexo
     */
    public String getSexo() {
        return sexo;
    }

    /**
     * @param sexo the sexo to set
     */
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    /**
     * @return the salario
     */
    public Double getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(Double salario) {
        this.salario = salario;
    }
}
